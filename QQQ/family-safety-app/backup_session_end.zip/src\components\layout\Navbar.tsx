'use client';

import Link from "next/link";
import { User, LogIn } from "lucide-react";
import { useAuth } from "@/components/Auth/AuthProvider";

export function Navbar() {
    const { user, loading } = useAuth();

    return (
        <header className="fixed top-0 left-0 right-0 h-16 bg-cyan-600 text-white shadow-md flex items-center justify-between px-4 z-50">
            <div className="flex items-center gap-2">
                <Link href="/" className="text-xl font-bold tracking-wide">
                    Kizuna Safety
                </Link>
            </div>
            {!loading && (
                <Link
                    href={user ? "/profile" : "/login"}
                    className="p-2 hover:bg-cyan-700 rounded-full transition-colors flex items-center justify-center"
                    aria-label={user ? "プロフィール" : "ログイン"}
                >
                    {user ? <User className="w-6 h-6" /> : <LogIn className="w-6 h-6" />}
                </Link>
            )}
        </header>
    );
}
