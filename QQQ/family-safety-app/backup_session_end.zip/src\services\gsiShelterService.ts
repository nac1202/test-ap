
import { Shelter } from "@/types/shelter";

// GSI Tile Base URL
const BASE_URL = "https://cyberjapandata.gsi.go.jp/xyz";

// Layer IDs for different disaster types
const LAYERS = {
    FLOOD: "skhb01",       // 洪水
    EARTHQUAKE: "skhb04",  // 地震
    TSUNAMI: "skhb05",     // 津波
} as const;

// Zoom level for fetching tiles (Z=10 is the level provided by GSI for skhb)
const ZOOM_LEVEL = 10;

interface GSIFeature {
    type: "Feature";
    properties: {
        name: string;
        address: string;
        [key: string]: any;
    };
    geometry: {
        type: "Point";
        coordinates: [number, number]; // [lon, lat]
    };
}

interface GSIGeoJSON {
    type: "FeatureCollection";
    features: GSIFeature[];
}

/**
 * Haversine distance in km
 */
function getDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number) {
    const R = 6371; // km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Convert Lat/Lon to Tile Coordinates (Z, X, Y)
 */
function latLonToTile(lat: number, lon: number, z: number): { x: number, y: number } {
    const x = Math.floor((lon + 180) / 360 * Math.pow(2, z));
    const y = Math.floor((1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, z));
    return { x, y };
}

/**
 * Fetch shelter data from GSI Tiles for a specific location and radius
 * For simplicity, we fetch a 3x3 grid of tiles around the center tile at Z=15.
 */
// Return type matches Shelter interface structure (flat lat/lon, note)
export async function fetchGSIShelters(lat: number, lon: number): Promise<Omit<Shelter, 'id' | 'createdAt'>[]> {
    const { x: centerX, y: centerY } = latLonToTile(lat, lon, ZOOM_LEVEL);

    // Determine tile range. At Z=10, one tile is ~30kmx30km.
    // To save mobile bandwidth (tiles can be 1-5MB each), we only fetch the center tile.
    const tiles = [
        { x: centerX, y: centerY, z: ZOOM_LEVEL }
    ];

    // Using a map to avoid duplicates if same shelter appears in multiple disaster layers
    const shelterMap = new Map<string, Omit<Shelter, 'id' | 'createdAt'>>();

    // Fetch from multiple layers
    const targetLayers = [LAYERS.EARTHQUAKE, LAYERS.FLOOD];

    // Fetch tiles in parallel for better performance
    const fetchPromises = [];
    for (const layer of targetLayers) {
        for (const tile of tiles) {
            fetchPromises.push(
                fetch(`${BASE_URL}/${layer}/${tile.z}/${tile.x}/${tile.y}.geojson`)
                    .then(res => {
                        if (!res.ok) return null;
                        return res.json() as Promise<GSIGeoJSON>;
                    })
                    .catch(e => {
                        console.warn(`Failed to fetch GSI tile: ${layer}/${tile.z}/${tile.x}/${tile.y}`, e);
                        return null;
                    })
            );
        }
    }

    const results = await Promise.all(fetchPromises);

    for (const data of results) {
        if (!data || !data.features) continue;

        for (const feature of data.features) {
            const name = feature.properties.name;
            const address = feature.properties.address;
            const [featureLon, featureLat] = feature.geometry.coordinates;

            // Filter out shelters that are too far away (e.g. > 5km) to avoid huge arrays
            const dist = getDistanceKm(lat, lon, featureLat, featureLon);
            if (dist > 5) continue;

            // Generate a unique key to deduplicate
            const key = `${name}-${featureLat.toFixed(6)}-${featureLon.toFixed(6)}`;

            if (!shelterMap.has(key)) {
                shelterMap.set(key, {
                    name: name,
                    address: address, // GSI address often contains full address
                    latitude: featureLat,
                    longitude: featureLon,
                    note: "【国土地理院データ】指定緊急避難場所"
                });
            }
        }
    }

    return Array.from(shelterMap.values());
}
